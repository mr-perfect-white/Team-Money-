<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MemberRegister extends Model
{
    protected $fillable = [
        'firstname', 
        'lastname', 
        'phone', 
        'email', 
        'permanent_addr', 
        'temporary_addr', 
        'document_one',
        'pan_num',
        'pan_doc',
        'adhr_num',
        'adhr_doc',
        'accnt_num',
        'accnt_ifsc_num',
        'accnt_brnch_dtl',
        'monthly_inc',
        'sadh_mem',
        'sadh_mem_id',
    ];

    public function getFullNameAttribute()
{
    return $this->firstname . ' ' . $this->lastname;
}

    public function getIsActiveAttribute()
    {
        return $this->status == 1 ? 'New' : 'Added';
    }
}
